# Security Policy

## Supported Versions

currently being supported with bug fixes.

| Version | Supported          |
| ------- | ------------------ |
| 4.5.0   | :white_check_mark: |
| 4.5.1   | :white_check_mark: |
| 4.5.2   | :white_check_mark: |
| 4.5.3   | :white_check_mark: |

## Reporting a Vulnerability

- if you find a bug then lemme know i will fix this asap 
- Email me with proper details and screenshots.
- support@hackerwasii.com
